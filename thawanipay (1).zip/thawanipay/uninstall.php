<?php

defined('BASEPATH') or exit('No direct script access allowed');

delete_option('paymentmethod_thawanipay_description_dashboard');
delete_option('paymentmethod_thawanipay_initialized');
delete_option('paymentmethod_thawanipay_default_selected');
delete_option('paymentmethod_thawanipay_currencies');
delete_option('paymentmethod_thawanipay_key_secret');
delete_option('paymentmethod_thawanipay_key_id');
delete_option('paymentmethod_thawanipay_label');
delete_option('paymentmethod_thawanipay_active');
