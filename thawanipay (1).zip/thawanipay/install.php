<?php

defined('BASEPATH') or exit('No direct script access allowed');

add_option('thawanipay', 'enable');